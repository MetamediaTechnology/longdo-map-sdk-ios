//
//  LongdoMapSDK.h
//  LongdoMapSDK
//
//  Created by กมลภพ จารุจิตต์ on 23/9/59.
//  Copyright © พ.ศ. 2559 Metamedia Technology. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LongdoMapSDK.
FOUNDATION_EXPORT double LongdoMapSDKVersionNumber;

//! Project version string for LongdoMapSDK.
FOUNDATION_EXPORT const unsigned char LongdoMapSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LongdoMapSDK/PublicHeader.h>
#import "Annotation.h"
#import "MKMapView+Longdo.h"
